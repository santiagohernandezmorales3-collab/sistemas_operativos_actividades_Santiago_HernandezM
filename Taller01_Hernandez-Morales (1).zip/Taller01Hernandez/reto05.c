// pontificia universidad javeriana
//  Autor: Santiago Hernandez Morales.
//  fecha:21/08/2025
//  Materia:Sistemas operativos.
// temas-memoria dinamica.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// se declara la funcion principal.
int main() {
  // se declara un puntero ptr y las variables i,n1,n2 de tipo entero.
  int *ptr, i, n1, n2;
  // se imprime el siguiente mensaje el cual solicita al usuario el tamaño del
  // arreglo.
  printf("Enter size:");
  // se lee el tamaño que asigno el usuario para el arreglo utilizando un scanf.
  scanf("%d", &n1);
  // se reserva el espacio de memoria para el arreglo que tiene el tamaño que
  // asigno el usuario.
  ptr = (int *)malloc(n1 * sizeof(int));
  // seimprime el siguiente mensaje.
  printf("Adresses of previously allocated memory:");
  /* se utiliza un ciclo for con el proposito de imprimir las direcciones de memoria que tiene el arreglo */
  for (i = 0; i < n1; ++i)
    /* se imprime las direcciones de memoria del arreglo.*/
    printf("\n\np = %p\n", ptr + i);
  /* se imprime el siguiente mensaje el cual solicita al usuario el nuevo tamaño*/
  // del arreglo.
  printf("\n Enter the new size:");
  scanf("%d", &n2);
  // rellocating the memory
  ptr = realloc(ptr, n2 * sizeof(int));
  printf("Addresses of newly allocated memory:");
  for (i = 0; i < n2; ++i)
    printf("\n\np=%p\n", ptr + i);
  free(ptr);
}