/*pontificia universidad javeriana
 Autor: Santiago Hernandez Morales.
 fecha:21/08/2025
 Materia:Sistemas operativos.
temas-memoria dinamica.*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
  // se declata un puntero sin inicializar.
  char *p;
  // se inicializa el puntero q con Null
  char *q = NULL;
  // se imprime la direccion de memoria del puntero p
  printf("Direccion de p: %s\n", p);
  // se imprime el siguiente mensaje.
  strcpy(p, "Hola, soy el mejor en sistemas operativos!!");
  // se imprime el contenido de p
  printf("%s\n", p);
  // se imprime el siguiente mensaje de despedida.
  printf("About to cpy\"Goodbye\"to q\n");
  // se imprime el contenido de q y se le asigna el mensaje de goodbye.
   printf("se va a copiar ****Godbye**** to q\n");
  strcpy(q, "Goodbye");
  printf("Cadena Copiada\n");
  printf("%s\n", q);
  // se imprime el contenido de q
  printf("%s\n", q);
// devuelve 0 ppara indicar que el programa se ejecuto correctamente.
  return 0;
}







