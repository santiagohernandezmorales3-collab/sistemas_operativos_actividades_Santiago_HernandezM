//pontificia universidad javeriana
// Autor: Santiago Hernandez Morales.
// fecha:21/08/2025
// Materia:Sistemas operativos.
//temas-memoria dinamica.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//se declara la funcion principal.
int main(){
  // se declara un puntero q con null.
  char *q=NULL;
  //se imprime el siguiente mensaje de solicitud de memoria para goodbye.
  printf("solicitando memoria para GoodBye\n");
  //se reserva el espacio de memoria para goodbye.
  q=(char*)malloc(strlen("Goodbye")+1);
  
// se verifica si la reserva de memoria fue exitosa, teniendo en cuenta que si no lo fue se imprime un mensaje de falla de reserva de memoria y se termina el programa
  if(!q){
    // se imprime el mensaje de falla de reserva de memoria
    perror("Falla de reserva de memoria");
    // se termina el programa.
    exit(1);
  }
  // se imprime el siguiente mensaje de solicitud de memoria para goodbye
  printf("About to copy\"Goodbye to q at adress %s\n",q);
  // se copia el mensaje goodbye en la direccion de memoria de q
  strcpy(q,"goodbye");
  // se imprime el siguiente mensaje de confirmacion de copia de cadena.
  printf("String copied\n");
  // se imprime el dcontenido de q
  printf("%s\n",q);
  //retorna 0 para indicar que el programa se ejecuto correctamente.
  return 0;

  }