//pontificia universidad javeriana
// Autor: Santiago Hernandez Morales.
// fecha:21/08/2025
// Materia:Sistemas operativos.
//temas-memoria dinamica.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// se declara la funcion principal.
int main(){
  // se declaran las variables n,i,sum y el puntero ptr.
  int n, i,*ptr,sum=0;
  // se imprime el siguiente mensaje para solicitar al usuario el numero de elementos.
  printf("Enter number of elements:");
  //se lee el numero de elementos.
  scanf("%d",&n);
  //se reserva el espacio de memoria para el arreglo de n elementos.
  ptr=(int*)calloc(n,sizeof(int));
  //se verifica si la reserva de memoria tuvo exito, de lo contrario se imprime un mensaje de error y se termina el programa.
  if(ptr==NULL){
    //se imprime el siguiente mensaje de error.
    printf("Error! memory not allocated.");
    // se termina de ejecutar el programa.
    exit(0);
  }
  //se imprime el siguiente mensaje si la reserva de memoria tuvo exito, lo que permite al usuario ingresar los elementos del arreglo
  // se utiliza un ciclo for con el proposito de leer los elementos de un arreglo y sumarlos.
  for(i=0; i<n; ++i){

    printf("Enter the number of elements %d: ",i+1);
    scanf("%d",ptr+i);
    //se lee los elementos ingresados por el usuario usando scanf.
    //se suman los elementos ingresados por el usuario.
    sum+=*(ptr+i);
  }
  // se imprime el resultado de la suma de los elementos ingresados por el usuario.
  printf("sum = %d\n ",sum);
  //se libera el espacio de memoria reservado en el arreglo.
  free(ptr);
  //se retorna 0 para indicar que el programa se ejecuto correctamente.
  return 0;
}