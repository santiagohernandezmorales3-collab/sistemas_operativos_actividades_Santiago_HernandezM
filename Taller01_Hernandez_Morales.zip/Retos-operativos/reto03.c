//pontificia universidad javeriana
// Autor: Santiago Hernandez Morales.
// fecha:21/08/2025
// Materia:Sistemas operativos.
//temas-memoria dinamica.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){


  int *ptr;
  ptr=malloc(15*sizeof(*ptr)); //un bloque de memoria de 15 valores enteros.

  if(ptr !=NULL){
    *(ptr+5)=480; //asigna el valor 480 a la posicion 6 del arreglo.
    printf("Value of the 6th integer is %d\n", *(ptr+5));
    
  }
  return 0;
}